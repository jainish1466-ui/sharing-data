from fastapi import FastAPI;

app = FastAPI()

@app.get("/")
def hello_world():
    return {"message":"Hello, World"}

@app.post("/")
def hello_world():
    return {"message":"Hello, World"}